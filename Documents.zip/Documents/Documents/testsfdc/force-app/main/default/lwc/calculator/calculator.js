
import { LightningElement } from 'lwc';
export default class Calculator extends LightningElement {
  avaljs;
  bvaljs;
  resultjs;

  avalueEvent(event){
      this.avaljs=event.target.value;
  }

   bvalueEvent(event){
      this.bvaljs=event.target.value;
  }

    sumClick(event){
      this.resultjs=(parseInt(this.avaljs)+parseInt(this.bvaljs));
  }
  subClick(event){
      this.resultjs=(this.avaljs-this.bvaljs);
  }

   mulClick(event){
      this.resultjs=(this.avaljs*this.bvaljs);
  }

   divClick(event){
      this.resultjs=(this.avaljs/this.bvaljs);
  }

  
}

