import { LightningElement } from 'lwc';
export default class StudentDataLWC extends LightningElement {
    namejs='Ankit';
    emailjs='def@gmail.com';
    phonejs='12345';
    collegejs='IIITDm'



   nameevent1(event){
        this.namejs =event.target.value;
        
    }
    nameevent2(event){
        this.emailjs =event.target.value;
       
    }
    nameevent3(event){
        this.phonejs =event.target.value;
    }
    nameevent4(event){
        this.collegejs =event.target.value;
    }




}