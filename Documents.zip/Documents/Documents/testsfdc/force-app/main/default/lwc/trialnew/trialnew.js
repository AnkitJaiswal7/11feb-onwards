import { LightningElement } from 'lwc';

export default class Trialnew extends LightningElement {}