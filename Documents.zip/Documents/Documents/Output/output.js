<script>
    //4
    let z=[1,2,3,4]
    //let a = { name: "anil"};
    console.warn(...z);
</script>