import { LightningElement, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import getContactsByAccountId from '@salesforce/apex/ContactController.getContactsByAccountId';
import getAccountOptions from '@salesforce/apex/AccountController.getAccountOptions';
const PAGE_SIZE = 10;


export default class assignmentByJahnavi extends NavigationMixin(LightningElement) {
    @track selectedAccount;
    @track accountOptions = [];
    @track contacts = [];
    @track displayContacts = [];
    @track currentPage = 1;
    @track disablePrev = true;
    @track disableNext = true;


    connectedCallback() {
        this.loadAccountOptions();
    }


    loadAccountOptions() {
       
        getAccountOptions()
            .then(result => {

                this.accountOptions = result.map(account => ({
                    label: account.Name,
                    value: account.Id
                }));
            })
            .catch(error => {
                console.error('Error retrieving account options:', error);
            });
    }
    


    handleAccountChange(event) {
        this.selectedAccount = event.detail.value;
        this.loadContacts();
    }


    loadContacts() {
        
        const accountId = this.selectedAccount;
        getContactsByAccountId({ accountId })
            .then(result => {
                this.contacts = result;
                this.updateDisplayContacts();
            })
            .catch(error => {
                console.error('Error retrieving contacts:', error);
            });
    }


    updateDisplayContacts() {
        const startIndex = (this.currentPage - 1) * PAGE_SIZE;
        const endIndex = startIndex + PAGE_SIZE;
        this.displayContacts = this.contacts.slice(startIndex, endIndex);
        this.updateNavigationButtons();
    }


    handleContactClick(event) {
        const contactId = event.target.dataset.contactId;
        this.navigateToContactDetails(contactId);
    }


    navigateToContactDetails(contactId) {
        
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: contactId,
                objectApiName: 'Contact',
                actionName: 'view'
            }
        });
    }


    handlePrevClick() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.updateDisplayContacts();
        }
    }


    handleNextClick() {
        const maxPages = Math.ceil(this.contacts.length / PAGE_SIZE);
        if (this.currentPage < maxPages) {
            this.currentPage++;
            this.updateDisplayContacts();
        }
    }


    updateNavigationButtons() {
        const maxPages = Math.ceil(this.contacts.length / PAGE_SIZE);
        this.disablePrev = this.currentPage === 1;
        this.disableNext = this.currentPage === maxPages || maxPages === 0;
    }
}
