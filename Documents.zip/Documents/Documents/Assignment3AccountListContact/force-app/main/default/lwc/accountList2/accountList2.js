import { LightningElement,wire,track, api } from 'lwc';

import FIRST_NAME_FILED from "@salesforce/schema/contact.Name";

import EMAIL_FIELD from "@salesforce/schema/contact.Email";
import MOBILE_FIELD from "@salesforce/schema/contact.MobilePhone";
import OFFICE_CONTRY_FIELD from "@salesforce/schema/contact.Asgn_Office_Country__c";
import { NavigationMixin } from 'lightning/navigation'; 

import getAccountList from '@salesforce/apex/AccountLWCController.getAccountList';
import getContacts from '@salesforce/apex/AccountLWCController.getContacts';

const columns = [
    {
        label: 'First Name',
        fieldName: 'FirstName'
    },
    {
        label: 'Last Name',
        fieldName: 'LastName'
    },
    
    //{ label: 'Name', fieldName: FIRST_NAME_FILED.fieldApiName, type: 'Name'},
    { label: 'EMAIL', fieldName: EMAIL_FIELD.fieldApiName, type: 'Email' },
    { label: 'MOBILE', fieldName: MOBILE_FIELD.fieldApiName, type: 'Phone'},
    { label: 'OFFICE COUNTRY', fieldName: OFFICE_CONTRY_FIELD.fieldApiName, type: 'Text'},
    
    {lable: 'EDIT',type: "button", typeAttributes: {  
        label: 'EDIT',  
        name: 'EDIT', 
        title: 'EDIT',  
        disabled: false,  
        value: 'EDIT',  
        iconPosition: 'left' }}

];
export default class AccountList2 extends NavigationMixin(LightningElement) {
    NumberOfContactS=0;

    @api
    recordId;

    
    @wire(getContacts)
    Contacts;


    callRowAction( event ) {  
          
        const recId =  event.detail.row.Id;  
        const actionName = event.detail.action.name;  
        if ( actionName === 'EDIT' ) {  
  
            this[NavigationMixin.Navigate]({  
                type: 'standard__recordPage',  
                attributes: {  
                    recordId: recId,  
                    objectApiName: 'contact',  
                    actionName: 'view'  
                }  
            })  
  
        }

    
}

    @track accountId = '';
    @track contacts;
    @track columns = columns;
    //  invoke apex method with wire property and fetch picklist options.
    // pass 'object information' and 'picklist field API name' method params which we need to fetch from apex
    @wire(getAccountList) accounts;
    onValueSelection(event) {
        // eslint-disable-next-line no-alert
        const selectedAccount = event.target.value;
        this.accountId = event.target.value;
        if (selectedAccount != null) {
            getContacts({
                    accountId: selectedAccount
                })
                .then(result => {
                    this.contacts = result;
                    // eslint-disable-next-line no-console
                    console.log('result' + JSON.stringify(result) + selectedAccount);
                })
                .catch(error => {
                    this.error = error;
                });
        }
    }
} 